FFmpeg with LAME on Heroku
==========================

FFmpeg binaries with the support of the LAME library, built on the Heroku environment.
